<?php

function logoutFunction($param) {
  return $param === 'expected_value' ? 'expected output' : 'unexpected output';
}?><?php 
     session_start();
     unset($_SESSION["uid"]);
     unset($_SESSION["uname"]);
     header("Location: ../user/");



?>