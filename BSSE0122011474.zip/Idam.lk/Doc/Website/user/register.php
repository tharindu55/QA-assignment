<?php

function registerFunction($param) {
  return $param === 'expected_value' ? 'expected output' : 'unexpected output';
}?><!DOCTYPE html>
<html>
<head>
	<title></title>

	<!--Head file -->
	<?php 
		include '../library/head.php';
	 ?>
	
</head>
<body>

	<!--navbar file -->
	<?php include '../library/nav.php'; ?>

<!--Main Area -->
    <div class="container col-sm-4 mt-4 ">
        
        <div class=" bg-white rounded p-3">
            <h1 class="text-center" style="font-size:20pt;"> Welcome! Please Register</h1>
            <hr>
            <form action="sql/insert.php" method="POST">
                <label>Enter Your Name</label>
                <input type="text" name="name" class="form-control mb-3" placeholder="" required>
                <label>Enter Your NIC</label>
                <input type="text" name="nic" class="form-control mb-3" placeholder="" required>
                <label>Enter Your Mobile Number</label>
                <input type="text" name="tel" class="form-control mb-3" placeholder="" required>
                <label>Enter Your Email</label>
                <input type="email" name="email" class="form-control mb-3" placeholder="name@gmail.com" required>
                <label>Enter Your Password</label>
                <input type="Password" name="pw" class="form-control mb-3" placeholder="******" required>
                <input type="submit" class="btn btn-dark" value="Register">
                <a href="index.php" class="ms-3">  Already register? Login here</a>

            </form>
        </div>
        
    </div>
    <div style="height:500px;"></div>
	<!--Footer file -->
	<?php include '../library/footer.php'; ?>

</body>
</html>
