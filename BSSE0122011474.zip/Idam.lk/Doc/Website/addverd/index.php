<!DOCTYPE html>
<html>
<head>
	<title></title>

	<!--Head file -->
	<?php 
		include '../library/head.php';
	 ?>
	
</head>
<body>

	<!--navbar file -->
	<?php include '../library/nav.php'; ?>

    <?php 
   
    $aid=$_REQUEST["aid"];
     $sql= " SELECT * FROM addvertisement INNER JOIN images ON addvertisement.aid=images.aid 
   WHERE addvertisement.aid='$aid'  ";
    $result = $conn->query($sql);
    while($row = $result->fetch_assoc())
    { ?>

<!--Main Area -->
    <div class="container mt-4 bg-white rounded addverd">
        <div class="row">
        
            <!--(left)-->
            <div class="col-sm-8 col-lg-8 py-3">
                <h1><?php echo $row["title"]; ?></h1>
                <p>Posted <?php echo $row["date_time"]; ?> | <?php echo $row["city"]; ?>, Srilanka</p>

                <!--Image carousel -->
                <div>
	         <?php include 'carousel.php'; ?>
                </div>

                <p class="price f-cl1">Rs.<?php echo number_format($row["price"]); ?>/=</p>
                <p> 
                    Area : <b><?php echo $row["city"]; ?>, Srilanka</b><br> 
                    Bedrooms : <?php echo $row["bed"]; ?> | Bathroom : <?php echo $row["bath"]; ?> <br>
                    Land size : <?php echo $row["size"]; ?> perches
                </p>

                <p> 
                    <b>Description</b><br> 
                    <span class="desc">
                    <?php echo $row["description"]; ?></span>
                    
                </p>


            </div>
              <!--(left END)-->

               <!--(Right)-->
            <div class="col-sm-4  py-3 pt-5 sticky-top">
                <div class="border p-3 text-center sticky-top">
                        <h2>Contact Advertiser</h2>
                        <p class="tel"><i class="fa fa-phone"></i><?php echo $row["tel"]; ?></p>


                </div>



            </div>
             <!--(Right END)-->



        </div>
    </div>

    <?php } ?>























	<!--Footer file -->
	<?php include '../library/footer.php'; ?>

</body>
</html>
