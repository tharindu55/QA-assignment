<?php
header("location: home/")
?>