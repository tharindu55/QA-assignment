
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<!--Head file -->
	<?php 
		include '../library/head.php';
	 ?>
</head>
<body>
	<!--navbar file -->
	<?php include '../library/nav.php'; ?>

    <?php 
         
         include 'login_check.php';
         $uid=$_SESSION["uid"];
         include '../library/dbconn.php';
    ?>

<!--Main Area -->
    <div class="container  bg-white mt-4 p-3">
        <p style="font-size:22pt;">Welcome! <?php echo $_SESSION["uname"]; ?> </p>
        <a href="index.php" class="btn btn-dark">Go Back</a>

        <h1 class="mt-4"> Post New Add</h1>
        <form action="sql/insert.php" method="POST" enctype="multipart/from-data">
            <div class="row">
                <div class="col-sm-6 mb-3">
                    <label>Add Title</Title></label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="col-sm-6 mb-3">
                    <label>City</Title></label>
                    <input type="text" name="city" class="form-control" required>
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Size</Title></label>
                    <input type="text" name="size" class="form-control" required>
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Bedrooms</Title></label>
                    <input type="text" name="bed" class="form-control" required>
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Bathrooms</Title></label>
                    <input type="text" name="bath" class="form-control" required>
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Price</Title></label>
                    <input type="text" name="price" class="form-control" required>
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Mobile number</Title></label>
                    <input type="text" name="tel" class="form-control" required>
                </div>
                <div class="col-sm-12 mb-3">
                    <label>Description</Title></label>
                    <textarea name="description" class="form-control" style="height: 200px;" required></textarea>
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Image 01</Title></label>
                    <input type="file" name="img1" class="form-control" >
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Image 02</Title></label>
                    <input type="file" name="img2" class="form-control" >
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Image 03</Title></label>
                    <input type="file" name="img3" class="form-control" >
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Image 04</Title></label>
                    <input type="file" name="img4" class="form-control" >
                </div>
                <div class="col-sm-4 mb-3">
                    <label>Image 05</Title></label>
                    <input type="file" name="img5" class="form-control" >
                </div>
                <div class="col-sm-12 mb-3">
                    <input type="submit" class="btn btn-success w-100">
                </div>
            </div>
        </form>
    </div>
    
<!--Main Area END -->

<div style="height:400px;"></div>

	<!--Footer file -->
	<?php include '../library/footer.php'; ?>

</body>
</html>


