<?php 
    //DB CONN
    $conn=new mysqli("localhost","root","","idam_web");
    //Time Zone
    date_default_timezone_set("asia/Colombo")
?>