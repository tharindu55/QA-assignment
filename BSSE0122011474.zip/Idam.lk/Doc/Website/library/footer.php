<div class="container-fluid bg-dark text-white py-2 mt-5 mb-0">
    <p class="text-center m-0">2024 Krishan.All rights reserved</p>
</div>